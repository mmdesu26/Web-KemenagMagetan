export const videos = [
  {
    id: 1,
    title: "Tutorial Pendaftaran Sertifikasi Halal",
    image: "/assets/images/video1.jpg",
    url: "https://www.youtube.com/watch?v=abcd1234"
  },
  {
    id: 2,
    title: "Panduan Manasik Haji Lansia",
    image: "/assets/images/video2.jpg",
    url: "https://www.youtube.com/watch?v=efgh5678"
  },
  {
    id: 3,
    title: "MOOC Pintar - Belajar Agama Digital",
    image: "/assets/images/video3.jpg",
    url: "https://www.youtube.com/watch?v=ijkl9101"
  },
  {
    id: 4,
    title: "Ucapan Menteri Agama Hari Santri 2025",
    image: "/assets/images/video1.jpg",
    url: "https://www.youtube.com/watch?v=mnop1121"
  }
];